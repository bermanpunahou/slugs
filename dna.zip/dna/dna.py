# Name & class period
# Problem name
# Program summary